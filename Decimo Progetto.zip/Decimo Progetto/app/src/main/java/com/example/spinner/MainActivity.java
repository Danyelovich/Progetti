package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerDinamico = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnerDinamico = findViewById(R.id.spinnerDinamico);
        String[] nomiPersone = new String[]{"Lorenzo", "Giorgio", "Luca"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nomiPersone);// 3 parametri: contesto (this), modello di View utilizzato, array utilizzato (nomiPersone)

        spinnerDinamico.setAdapter(adapter);//rende visibile lo spinner e si possono caricare oggetti su di esso
    }

    @Override
    protected void onResume() {
        super.onResume();
        spinnerDinamico.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {//seleziona lo spinner al click dell'oggetto

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {//parametri: adapter, View, indice elemento selezionato, id elemento selezionato
                String text1 = parent.getItemAtPosition(position).toString();//recupera la posizione dell'elemento selezionato e lo converte in una stringa
                Toast.makeText(parent.getContext(), text1, Toast.LENGTH_LONG).show();//stampa con un Toast l'elemento selezionato ora di tipo stringa
                text1 = ((String) spinnerDinamico.getSelectedItem());//ottiene il valore selezionato dallo spinner (ritorna un Object che deve essere convertito nel tipo utilizzato dallo Spinner (questo caso String))
                Toast.makeText(parent.getContext(), text1, Toast.LENGTH_LONG).show();
                text1 = (""+spinnerDinamico.getSelectedItemPosition());//ottiene il numero dell'elemento selezionato (posizione nello Spinner)
                Toast.makeText(parent.getContext(), text1, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
